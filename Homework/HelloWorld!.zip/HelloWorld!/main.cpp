/* 
 * File:   main.cpp
 * Author: AndrewAdame
 *
 * Created on June 22, 2020, 11:52 PM
 */

#include <cstdlib>
#include <iostream>
using namespace std;
int main(int argc, char** argv) 
{
    cout << "Hello World! :D" << endl;
    return 0;
}

